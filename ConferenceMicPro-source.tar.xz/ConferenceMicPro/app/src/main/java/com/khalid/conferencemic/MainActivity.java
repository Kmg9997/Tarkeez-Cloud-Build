package com.khalid.conferencemic;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.AdapterView;
import android.widget.HorizontalScrollView;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BACKGROUND = 0xFF0B1220;
    private static final int SURFACE = 0xFF172235;
    private static final int TEXT = 0xFFE8F3FF;
    private static final int MUTED = 0xFF9AADC4;
    private static final int ACCENT = 0xFF45E2B1;
    private static final int WARNING = 0xFFFFC87A;

    private final String[] routes = {
            "تلقائي — السماعة المتصلة أو الهاتف",
            "سماعة سلكية — مع ميكروفونها إن توفر",
            "مكبر صوت بلوتوث — ميكروفون الهاتف",
            "سماعة بلوتوث — ميكروفون السماعة (مكالمات)",
            "مكبر صوت الهاتف — انتبه للصفير"
    };
    private final String[] routeValues = {"auto", "wired", "bt_media", "bt_call", "speaker"};
    private SharedPreferences prefs;
    private Button toggleButton;
    private TextView stateText;
    private TextView statusDetail;
    private TextView levelLabel;
    private ProgressBar levelMeter;
    private Spinner routeSpinner;
    private boolean suppressRouteChange = true;
    private final BroadcastReceiver statusReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            boolean on = intent.getBooleanExtra("on", false);
            String message = intent.getStringExtra("message");
            int level = intent.getIntExtra("level", 0);
            updateUI(on, message, level);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(BACKGROUND);
        getWindow().setNavigationBarColor(BACKGROUND);
        getWindow().getDecorView().setSystemUiVisibility(0);
        prefs = getSharedPreferences("mic_settings", MODE_PRIVATE);
        buildUI();
        suppressRouteChange = false;
    }

    private int dp(int n) { return (int) (n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextColor(color);
        t.setTextSize(size);
        t.setGravity(Gravity.RIGHT);
        t.setTextDirection(View.TEXT_DIRECTION_RTL);
        t.setTypeface(Typeface.DEFAULT, bold ? Typeface.BOLD : Typeface.NORMAL);
        return t;
    }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }
    private void pad(View v, int all) { v.setPadding(dp(all), dp(all), dp(all), dp(all)); }
    private LinearLayout.LayoutParams lp(int height, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, height < 0 ? height : dp(height));
        p.bottomMargin = dp(bottom);
        return p;
    }
    private void addGap(LinearLayout p, int h) {
        View gap = new View(this);
        p.addView(gap, lp(h, 0));
    }
    private LinearLayout panel() {
        LinearLayout p = column();
        pad(p, 17);
        p.setBackground(rounded(SURFACE, 19));
        return p;
    }

    private void buildUI() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BACKGROUND);
        LinearLayout root = column();
        root.setPadding(dp(17), dp(24), dp(17), dp(28));
        scroll.addView(root);
        setContentView(scroll);

        TextView english = text("C O N F E R E N C E  M I C", 12, ACCENT, true);
        english.setGravity(Gravity.CENTER);
        root.addView(english, lp(-2, 8));
        TextView heading = text("ميكروفون المؤتمرات", 26, TEXT, true);
        heading.setGravity(Gravity.CENTER);
        root.addView(heading, lp(-2, 5));
        TextView subhead = text("صوت مباشر واضح · صدى واقعي · تحكم كامل", 13, MUTED, false);
        subhead.setGravity(Gravity.CENTER);
        root.addView(subhead, lp(-2, 18));

        LinearLayout live = panel();
        stateText = text("●  متوقف", 18, MUTED, true);
        stateText.setGravity(Gravity.CENTER);
        live.addView(stateText, lp(-2, 8));
        statusDetail = text("اختر مخرج الصوت، ثم اضغط تشغيل.", 13, MUTED, false);
        statusDetail.setGravity(Gravity.CENTER);
        live.addView(statusDetail, lp(-2, 12));
        levelMeter = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        levelMeter.setMax(100);
        levelMeter.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        levelMeter.setProgress(0);
        live.addView(levelMeter, lp(6, 6));
        levelLabel = text("مستوى الميكروفون: 0%", 12, MUTED, false);
        levelLabel.setGravity(Gravity.CENTER);
        live.addView(levelLabel, lp(-2, 0));
        root.addView(live, lp(-2, 13));

        LinearLayout routePanel = panel();
        routePanel.addView(text("مصدر الصوت ومخرجه", 17, TEXT, true), lp(-2, 10));
        routeSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, routes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        routeSpinner.setAdapter(adapter);
        int selected = 0;
        String current = prefs.getString("route", "auto");
        for (int i = 0; i < routeValues.length; i++) if (routeValues[i].equals(current)) selected = i;
        routeSpinner.setSelection(selected);
        routeSpinner.setBackground(rounded(0xFF2A3A53, 12));
        routeSpinner.setPadding(dp(10), dp(5), dp(10), dp(5));
        routePanel.addView(routeSpinner, lp(52, 10));
        routeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, View v, int pos, long id) {
                if (suppressRouteChange) return;
                prefs.edit().putString("route", routeValues[pos]).apply();
                sendLiveUpdate();
                if (pos == 3) statusDetail.setText("ميكروفون البلوتوث يستخدم وضع المكالمات وقد تنخفض الجودة.");
                if (pos == 4) statusDetail.setText("ابتعد عن مكبر الهاتف لتجنب الصفير والتغذية الراجعة.");
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });
        routePanel.addView(text("في وضع مكبر البلوتوث يُستخدم ميكروفون الهاتف؛ وفي وضع المكالمات يُستخدم ميكروفون السماعة إن دعمه الجهاز.", 12, MUTED, false), lp(-2, 0));
        root.addView(routePanel, lp(-2, 13));

        LinearLayout fx = panel();
        fx.addView(text("هندسة الصوت", 18, TEXT, true), lp(-2, 12));
        addSlider(fx, "قوة الميكروفون", "gain", 0, 220, 100, "%");
        addSlider(fx, "قوة الصدى", "echo", 0, 100, 17, "%");
        addSlider(fx, "رنين القاعة", "room", 0, 100, 24, "%");
        root.addView(fx, lp(-2, 13));

        LinearLayout presets = panel();
        presets.addView(text("إعدادات جاهزة", 17, TEXT, true), lp(-2, 11));
        HorizontalScrollView horizontal = new HorizontalScrollView(this);
        horizontal.setHorizontalScrollBarEnabled(false);
        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        String[] labels = {"قاعة مؤتمرات", "صوت مباشر", "صدى خفيف", "قاعة كبيرة"};
        int[][] vals = {{110, 17, 24}, {100, 0, 0}, {108, 24, 13}, {110, 43, 54}};
        for (int i = 0; i < labels.length; i++) {
            final int[] preset = vals[i];
            Button button = new Button(this);
            button.setText(labels[i]);
            button.setTextSize(12);
            button.setAllCaps(false);
            button.setTextColor(TEXT);
            button.setBackground(rounded(0xFF2B3B56, 13));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(-2, dp(43));
            pp.leftMargin = dp(7);
            buttons.addView(button, pp);
            button.setOnClickListener(v -> {
                prefs.edit().putInt("gain", preset[0]).putInt("echo", preset[1]).putInt("room", preset[2]).apply();
                buildUI();
                suppressRouteChange = false;
                sendLiveUpdate();
            });
        }
        horizontal.addView(buttons);
        presets.addView(horizontal, lp(-2, 0));
        root.addView(presets, lp(-2, 18));

        toggleButton = new Button(this);
        toggleButton.setAllCaps(false);
        toggleButton.setTextSize(20);
        toggleButton.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        toggleButton.setTextColor(BACKGROUND);
        toggleButton.setBackground(rounded(ACCENT, 22));
        toggleButton.setOnClickListener(v -> {
            if (MicrophoneService.isRunning()) {
                startService(new Intent(this, MicrophoneService.class).setAction(MicrophoneService.ACTION_STOP));
                updateUI(false, "تم إيقاف تضخيم الصوت.", 0);
            } else { requestAndStart(); }
        });
        root.addView(toggleButton, lp(67, 14));

        TextView notice = text("للاستمرار أثناء قفل الشاشة: اضغط تشغيل أولاً، ثم اقفل الشاشة. يظهر إشعار دائم بزر إيقاف. قد تحتاج إلى السماح للتطبيق بالعمل دون تقييد البطارية.", 13, WARNING, false);
        notice.setPadding(dp(10), 0, dp(10), 0);
        root.addView(notice, lp(-2, 13));
        Button battery = new Button(this);
        battery.setText("إعدادات البطارية والتشغيل في الخلفية");
        battery.setTextSize(13);
        battery.setAllCaps(false);
        battery.setTextColor(TEXT);
        battery.setBackground(rounded(0xFF263750, 14));
        battery.setOnClickListener(v -> {
            try {
                Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                i.setData(Uri.parse("package:" + getPackageName()));
                startActivity(i);
            } catch (Exception ignored) { }
        });
        root.addView(battery, lp(49, 0));
        updateUI(MicrophoneService.isRunning(), MicrophoneService.isRunning() ? "الصوت يعمل في الخلفية." : "اختر مخرج الصوت، ثم اضغط تشغيل.", 0);
    }

    private void addSlider(LinearLayout parent, String name, String key, int min, int max, int defaultValue, String suffix) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView label = text(name, 14, TEXT, true);
        row.addView(label, new LinearLayout.LayoutParams(0, -2, 1));
        int stored = prefs.getInt(key, defaultValue);
        TextView number = text(stored + suffix, 14, ACCENT, true);
        number.setGravity(Gravity.LEFT);
        row.addView(number, new LinearLayout.LayoutParams(dp(65), -2));
        parent.addView(row, lp(-2, 0));
        SeekBar slider = new SeekBar(this);
        slider.setMax(max - min);
        slider.setProgress(stored - min);
        slider.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        slider.setThumbTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        parent.addView(slider, lp(43, 13));
        slider.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int p, boolean fromUser) {
                if (!fromUser) return;
                int n = p + min;
                number.setText(n + suffix);
                prefs.edit().putInt(key, n).apply();
                sendLiveUpdate();
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
    }

    private void sendLiveUpdate() {
        if (MicrophoneService.isRunning())
            startService(new Intent(this, MicrophoneService.class).setAction(MicrophoneService.ACTION_UPDATE));
    }
    private void requestAndStart() {
        ArrayList<String> missing = new ArrayList<>();
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.BLUETOOTH_CONNECT);
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), 199);
        else startMicrophone();
    }
    @Override public void onRequestPermissionsResult(int req, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(req, permissions, grants);
        if (req != 199) return;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            updateUI(false, "يلزم السماح باستخدام الميكروفون.", 0);
        } else { startMicrophone(); }
    }
    private void startMicrophone() {
        try {
            Intent i = new Intent(this, MicrophoneService.class).setAction(MicrophoneService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i);
            else startService(i);
            updateUI(true, "جار تهيئة الصوت…", 0);
        } catch (Exception e) {
            updateUI(false, "فشل التشغيل: " + e.getMessage(), 0);
        }
    }
    private void updateUI(boolean on, String message, int level) {
        if (toggleButton != null) {
            toggleButton.setText(on ? "■   إيقاف الميكروفون" : "🎙   تشغيل الميكروفون");
            toggleButton.setBackground(rounded(on ? 0xFFFF998E : ACCENT, 22));
        }
        if (stateText != null) {
            stateText.setText(on ? "●  الميكروفون يعمل" : "●  متوقف");
            stateText.setTextColor(on ? ACCENT : MUTED);
        }
        if (statusDetail != null && message != null) statusDetail.setText(message);
        if (levelMeter != null) levelMeter.setProgress(level);
        if (levelLabel != null) levelLabel.setText(String.format(Locale.getDefault(), "مستوى الميكروفون: %d%%", level));
    }
    @Override protected void onStart() {
        super.onStart();
        IntentFilter f = new IntentFilter(MicrophoneService.STATUS_ACTION);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(statusReceiver, f, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(statusReceiver, f);
        updateUI(MicrophoneService.isRunning(), null, 0);
    }
    @Override protected void onStop() {
        super.onStop();
        unregisterReceiver(statusReceiver);
    }
}
