package com.khalid.conferencemic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.media.AudioAttributes;
import android.media.AudioDeviceCallback;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.media.AudioTrack;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.util.Log;
import java.util.concurrent.atomic.AtomicBoolean;

public class MicrophoneService extends Service {
    public static final String ACTION_START = "com.khalid.conferencemic.START";
    public static final String ACTION_UPDATE = "com.khalid.conferencemic.UPDATE";
    public static final String ACTION_STOP = "com.khalid.conferencemic.STOP";
    public static final String STATUS_ACTION = "com.khalid.conferencemic.STATUS";
    private static final String CHANNEL_ID = "live_microphone_v1";
    private static final int NOTIFICATION_ID = 51;
    private static volatile boolean running = false;

    private final AtomicBoolean active = new AtomicBoolean(false);
    private volatile Thread audioThread;
    private volatile String route = "auto";
    private volatile float gain = 1f;
    private volatile float echo = .17f;
    private volatile float room = .24f;
    private AudioManager audioManager;
    private PowerManager.WakeLock wakeLock;
    private AudioDeviceCallback deviceCallback;

    public static boolean isRunning() { return running; }
    @Override public IBinder onBind(Intent intent) { return null; }
    @Override public void onCreate() {
        super.onCreate();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        NotificationManager n = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "الميكروفون المباشر", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("مؤشر بأن الميكروفون يعمل، مع زر إيقاف سريع");
        n.createNotificationChannel(channel);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "ConferenceMicPro:LiveAudio");
        wakeLock.setReferenceCounted(false);
        deviceCallback = new AudioDeviceCallback() {
            @Override public void onAudioDevicesRemoved(AudioDeviceInfo[] devices) {
                if (!active.get()) return;
                for (AudioDeviceInfo dev : devices) {
                    int type = dev.getType();
                    if (type == AudioDeviceInfo.TYPE_WIRED_HEADSET || type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                            type == AudioDeviceInfo.TYPE_USB_HEADSET || type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                            type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || type == AudioDeviceInfo.TYPE_BLE_HEADSET ||
                            type == AudioDeviceInfo.TYPE_BLE_SPEAKER) {
                        // Never suddenly redirect amplified live audio to the handset after a headset disconnect.
                        sendStatus(false, "انفصل جهاز الصوت. أُوقف الميكروفون للحماية من الصفير.", 0);
                        stopSelf();
                        break;
                    }
                }
            }
        };
        audioManager.registerAudioDeviceCallback(deviceCallback, new Handler(Looper.getMainLooper()));
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_START : intent.getAction();
        if (ACTION_STOP.equals(action)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        String previousRoute = route;
        updateSettings();
        if (ACTION_UPDATE.equals(action) && active.get()) {
            if (!previousRoute.equals(route)) {
                stopAudio();
                startAudio();
            }
            return START_NOT_STICKY;
        }
        if (!active.get()) {
            try {
                Notification notification = makeNotification();
                if (Build.VERSION.SDK_INT >= 29) {
                    startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
                } else {
                    startForeground(NOTIFICATION_ID, notification);
                }
                if (!wakeLock.isHeld()) wakeLock.acquire();
                startAudio();
            } catch (Exception ex) {
                sendStatus(false, "خطأ في تشغيل الميكروفون: " + ex.getMessage(), 0);
                stopSelf();
            }
        }
        return START_NOT_STICKY;
    }

    private Notification makeNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openIntent = PendingIntent.getActivity(this, 10, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, MicrophoneService.class).setAction(ACTION_STOP);
        PendingIntent stopIntent = PendingIntent.getService(this, 11, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(com.khalid.conferencemic.R.drawable.mic_icon)
                .setContentTitle("ميكروفون المؤتمرات يعمل")
                .setContentText("الصوت مباشر حتى عند إغلاق الشاشة · اضغط للإعدادات")
                .setContentIntent(openIntent)
                .addAction(android.R.drawable.ic_media_pause, "إيقاف الميكروفون", stopIntent)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }

    private void updateSettings() {
        android.content.SharedPreferences p = getSharedPreferences("mic_settings", MODE_PRIVATE);
        gain = p.getInt("gain", 100) / 100f;
        echo = p.getInt("echo", 17) / 100f;
        room = p.getInt("room", 24) / 100f;
        route = p.getString("route", "auto");
    }

    private void startAudio() {
        if (active.get()) return;
        active.set(true);
        running = true;
        audioThread = new Thread(this::runAudio, "ConferenceMic-Audio");
        audioThread.setPriority(Thread.MAX_PRIORITY);
        audioThread.start();
        sendStatus(true, "جاري تهيئة مخرج الصوت…", 0);
    }
    private void stopAudio() {
        active.set(false);
        running = false;
        Thread t = audioThread;
        if (t != null && t != Thread.currentThread()) {
            t.interrupt();
            try { t.join(700); } catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        }
        audioThread = null;
    }
    private static boolean isType(int actual, int... types) {
        for (int type : types) if (actual == type) return true;
        return false;
    }
    private AudioDeviceInfo findDevice(boolean outputs, int... wantedTypes) {
        AudioDeviceInfo[] devices = audioManager.getDevices(outputs ? AudioManager.GET_DEVICES_OUTPUTS : AudioManager.GET_DEVICES_INPUTS);
        for (AudioDeviceInfo dev : devices) if (isType(dev.getType(), wantedTypes)) return dev;
        return null;
    }

    private void configureRoute(String selected) {
        if (Build.VERSION.SDK_INT >= 31) audioManager.clearCommunicationDevice();
        audioManager.setMode(AudioManager.MODE_NORMAL);
        if (!"bt_call".equals(selected)) return;
        if (Build.VERSION.SDK_INT < 31) throw new IllegalStateException("ميكروفون البلوتوث يتطلب أندرويد 12 أو أحدث");
        audioManager.setMode(AudioManager.MODE_IN_COMMUNICATION);
        AudioDeviceInfo bluetooth = null;
        for (AudioDeviceInfo d : audioManager.getAvailableCommunicationDevices()) {
            if (isType(d.getType(), AudioDeviceInfo.TYPE_BLUETOOTH_SCO, AudioDeviceInfo.TYPE_BLE_HEADSET)) {
                bluetooth = d;
                break;
            }
        }
        if (bluetooth == null || !audioManager.setCommunicationDevice(bluetooth)) {
            throw new IllegalStateException("لا توجد سماعة بلوتوث تدعم وضع الميكروفون، أو أن إذن البلوتوث مفقود");
        }
    }

    private void runAudio() {
        AudioRecord record = null;
        AudioTrack track = null;
        String selected = route;
        try {
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_AUDIO);
            configureRoute(selected);
            boolean call = "bt_call".equals(selected);
            int sampleRate = call ? 16000 : 48000;
            int source = call ? MediaRecorder.AudioSource.VOICE_COMMUNICATION : MediaRecorder.AudioSource.MIC;
            AudioFormat inFormat = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build();
            AudioFormat outFormat = new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
            int inMin = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
            int outMin = AudioTrack.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            if (inMin <= 0 || outMin <= 0) throw new IllegalStateException("صيغة الصوت غير مدعومة على هذا الهاتف");
            record = new AudioRecord.Builder().setAudioSource(source).setAudioFormat(inFormat)
                    .setBufferSizeInBytes(Math.max(inMin * 2, 4096)).build();
            if (record.getState() != AudioRecord.STATE_INITIALIZED) throw new IllegalStateException("تعذّر فتح الميكروفون");
            AudioAttributes attr = new AudioAttributes.Builder()
                    .setUsage(call ? AudioAttributes.USAGE_VOICE_COMMUNICATION : AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build();
            track = new AudioTrack.Builder().setAudioAttributes(attr).setAudioFormat(outFormat)
                    .setBufferSizeInBytes(Math.max(outMin * 2, 4096))
                    .setTransferMode(AudioTrack.MODE_STREAM).build();
            if (track.getState() != AudioTrack.STATE_INITIALIZED) throw new IllegalStateException("تعذّر فتح مخرج الصوت");

            AudioDeviceInfo out = null;
            AudioDeviceInfo input = null;
            switch (selected) {
                case "wired":
                    out = findDevice(true, AudioDeviceInfo.TYPE_WIRED_HEADSET,
                            AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_USB_HEADSET,
                            AudioDeviceInfo.TYPE_USB_DEVICE);
                    input = findDevice(false, AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET);
                    if (out == null) throw new IllegalStateException("لا توجد سماعة سلكية متصلة");
                    break;
                case "bt_media":
                    out = findDevice(true, AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                            AudioDeviceInfo.TYPE_BLE_SPEAKER, AudioDeviceInfo.TYPE_BLE_HEADSET);
                    input = findDevice(false, AudioDeviceInfo.TYPE_BUILTIN_MIC);
                    if (out == null) throw new IllegalStateException("لا يوجد مكبر بلوتوث متصل للصوت الوسائطي");
                    break;
                case "speaker":
                    out = findDevice(true, AudioDeviceInfo.TYPE_BUILTIN_SPEAKER);
                    input = findDevice(false, AudioDeviceInfo.TYPE_BUILTIN_MIC);
                    break;
                case "bt_call":
                    // Communication routing selects its matching microphone automatically.
                    break;
                default:
                    // Let Android route media to the connected wire / Bluetooth output.
                    break;
            }
            if (out != null && !track.setPreferredDevice(out)) {
                throw new IllegalStateException("رفض النظام مخرج الصوت المحدد");
            }
            if (input != null) record.setPreferredDevice(input);

            int block = call ? 320 : 480;
            short[] inputBuffer = new short[block];
            short[] outputBuffer = new short[block];
            AudioProcessor processor = new AudioProcessor(sampleRate);
            track.play();
            record.startRecording();
            if (record.getRecordingState() != AudioRecord.RECORDSTATE_RECORDING)
                throw new IllegalStateException("المايكروفون غير متاح؛ ربما تستخدمه مكالمة أخرى");
            String label;
            switch (selected) {
                case "wired": label = "سماعة سلكية"; break;
                case "bt_media": label = "مكبر بلوتوث · ميكروفون الهاتف"; break;
                case "bt_call": label = "سماعة بلوتوث · وضع المكالمات"; break;
                case "speaker": label = "مكبر الهاتف · احذر الصفير"; break;
                default: label = "توجيه تلقائي";
            }
            sendStatus(true, "متصل: " + label + " · " + (sampleRate / 1000) + " kHz", 0);
            long lastUpdate = 0;
            while (active.get() && !Thread.currentThread().isInterrupted()) {
                int n = record.read(inputBuffer, 0, inputBuffer.length, AudioRecord.READ_BLOCKING);
                if (n <= 0) {
                    if (n == AudioRecord.ERROR_INVALID_OPERATION || n == AudioRecord.ERROR_DEAD_OBJECT)
                        throw new IllegalStateException("انقطع الميكروفون أثناء التشغيل (" + n + ")");
                    continue;
                }
                processor.process(inputBuffer, outputBuffer, n, gain, echo, room);
                int written = 0;
                while (written < n && active.get()) {
                    int w = track.write(outputBuffer, written, n - written, AudioTrack.WRITE_BLOCKING);
                    if (w < 0) throw new IllegalStateException("فشل إخراج الصوت (" + w + ")");
                    if (w == 0) break;
                    written += w;
                }
                long now = SystemClock.elapsedRealtime();
                if (now - lastUpdate > 170) {
                    sendStatus(true, null, processor.getLevel());
                    lastUpdate = now;
                }
            }
        } catch (Exception ex) {
            Log.e("ConferenceMic", "Audio engine stopped", ex);
            if (active.get()) {
                sendStatus(false, "تعذر التشغيل: " + (ex.getMessage() == null ? "خطأ في الصوت" : ex.getMessage()), 0);
                new Handler(Looper.getMainLooper()).post(this::stopSelf);
            }
        } finally {
            if (record != null) {
                try { record.stop(); } catch (Exception ignored) { }
                try { record.release(); } catch (Exception ignored) { }
            }
            if (track != null) {
                try { track.pause(); track.flush(); track.stop(); } catch (Exception ignored) { }
                try { track.release(); } catch (Exception ignored) { }
            }
            if (Build.VERSION.SDK_INT >= 31) {
                try { audioManager.clearCommunicationDevice(); } catch (Exception ignored) { }
            }
            try { audioManager.setMode(AudioManager.MODE_NORMAL); } catch (Exception ignored) { }
        }
    }

    private void sendStatus(boolean on, String message, int level) {
        Intent i = new Intent(STATUS_ACTION).setPackage(getPackageName());
        i.putExtra("on", on).putExtra("level", level);
        if (message != null) i.putExtra("message", message);
        sendBroadcast(i);
    }
    @Override public void onDestroy() {
        stopAudio();
        if (deviceCallback != null) audioManager.unregisterAudioDeviceCallback(deviceCallback);
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        if (Build.VERSION.SDK_INT >= 31) {
            try { audioManager.clearCommunicationDevice(); } catch (Exception ignored) { }
        }
        audioManager.setMode(AudioManager.MODE_NORMAL);
        stopForeground(STOP_FOREGROUND_REMOVE);
        sendStatus(false, "الميكروفون متوقف.", 0);
        super.onDestroy();
    }
}
