package com.khalid.conferencemic;

/**
 * Real-time, allocation-free mono speech DSP.
 * 90 Hz high-pass, smooth noise gate, 3:1-ish vocal compression,
 * a room early-reflection model and sparse delay taps, then peak limiting.
 * Echo and room are intentionally separate to avoid unstable feedback loops.
 */
final class AudioProcessor {
    private final float[] history;
    private final int size;
    private final int sampleRate;
    private final float hpDecay;
    private float previousInput = 0f;
    private float hpState = 0f;
    private float envelope = 0f;
    private float gate = 1f;
    private int index = 0;
    private int level = 0;

    AudioProcessor(int rate) {
        sampleRate = rate;
        size = rate; // 1-second history ring; no dynamic allocations on audio thread.
        history = new float[size];
        hpDecay = (float) Math.exp(-2.0 * Math.PI * 90.0 / rate);
    }
    int getLevel() { return level; }
    private float delayed(float seconds) {
        int delay = (int) (seconds * sampleRate);
        int pos = index - delay;
        if (pos < 0) pos += size;
        return history[pos];
    }
    void process(short[] input, short[] output, int count, float gain, float echo, float room) {
        double energy = 0;
        for (int i = 0; i < count; i++) {
            float x = input[i] / 32768f;
            // High-pass attenuates low-frequency rumble / plosives.
            float hp = hpDecay * (hpState + x - previousInput);
            previousInput = x;
            hpState = hp;
            envelope += .004f * (Math.abs(hp) - envelope);
            float gateTarget = envelope < .0027f ? .18f : 1f;
            gate += .002f * (gateTarget - gate);
            float compression = envelope > .11f ? (float) Math.pow(.11f / envelope, .62) : 1f;
            float dry = hp * gate * compression * 1.55f;
            history[index] = dry;

            // Realistic, discrete room reflections rather than a strong synthetic repeat.
            float roomSignal = .24f * delayed(.031f) + .20f * delayed(.047f)
                    + .15f * delayed(.071f) + .09f * delayed(.103f);
            float echoSignal = .42f * delayed(.134f) + .27f * delayed(.251f)
                    + .17f * delayed(.382f) + .11f * delayed(.523f);
            float y = (dry + room * roomSignal + echo * echoSignal) * gain;
            // Soft knee peak limiter, followed by safety hard clamp.
            float magnitude = Math.abs(y);
            if (magnitude > .82f) {
                float over = magnitude - .82f;
                float shaped = .82f + .18f * (over / (.18f + over));
                y = Math.copySign(shaped, y);
            }
            y = Math.max(-.995f, Math.min(.995f, y));
            output[i] = (short) (y * 32767f);
            energy += Math.min(1.0, Math.abs(dry)) * Math.min(1.0, Math.abs(dry));
            index++;
            if (index == size) index = 0;
        }
        double rms = Math.sqrt(energy / Math.max(1, count));
        level = (int) Math.min(100, Math.round(100.0 * Math.sqrt(rms * 2.5)));
    }
}
